<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Shop Homepage - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/')); ?>/css/shop.css" rel="stylesheet">

</head>

<body>

    <!-- Navigation -->
    <?php echo $__env->make('layouts.cart.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Page Content -->
    <div class="container">

        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <!-- /.container -->

    <div class="container">

        <hr>

        <!-- Footer -->
        <?php echo $__env->make('layouts.cart.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="<?php echo e(url('/')); ?>/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>

</body>

</html>