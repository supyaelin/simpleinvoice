<div class="col-sm-4 col-lg-4 col-md-4">
    <div class="thumbnail">
        <!-- <img src="<?php echo e(url('images/$item->image')); ?>" alt=""> -->
        <div class="caption">
            <h4 class="pull-right">$<?php echo e($item->price); ?></h4>
            <h4><a href="<?php echo e(url('item')); ?>/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a>
            </h4>
            <p><?php echo e($item->description); ?></p>
        </div>
        <div class="ratings">
            <p class="pull-right">15 reviews</p>
            <p>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
                <span class="glyphicon glyphicon-star"></span>
            </p>
        </div>
    </div>
</div>
