<?php $__env->startSection('content'); ?>
	
	<h1>Add New Item</h1>
	<hr>
	
	
	<form action="<?php echo e(url('items')); ?>" method="POST">
	<?php echo e(csrf_field()); ?>

	<?php echo $__env->make("layouts.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	  <div class="form-group">
	    <label for="name">Name:</label>
	    <input type="text" class="form-control" id="name" name="name">
	  </div>

	  <div class="form-group">
	    <label for="price">Price:</label>
	    <input type="text" class="form-control" id="price" name="price">
	  </div>

	  <div class="form-group">
	    <label for="description">Description</label>
	    <textarea id="description" name="description" class="form-control"></textarea>
	  </div>
	  <div class="form-group">
	    <label for="image">Image</label>
	    <input type="file" name="image" />
	    
	  </div>

	  <div class="form-group">
	  	<button type="submit" class="btn btn-primary">Add</button>
	  </div>
	</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cart.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>