<?php $__env->startSection('content'); ?>
	<div class="col-sm-8 blog-main">
		<h1><?php echo e($post->title); ?></h1>
		<?php echo e($post->body); ?>

		<hr>
		<div class="comments">
		<ul class="list-group">
			<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>	
				<li class="list-group-item">
					<strong>
						<?php echo e($comment->created_at->diffForHumans()); ?>: &nbsp;
					</strong>
					<?php echo e($comment->body); ?>

				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
		</div>
		<hr>

		<div class="card">
			<div class="card-block">
				<form method="POST" action="<?php echo e(url('/')); ?>/posts/<?php echo e($post->id); ?>/comments">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
					<div class="form-group">
						<textarea name="body" Placeholder="Your Comment here!" class="form-control" rows="3"></textarea>
					</div>	
					<div class="form-group">
						<button class="btn btn-primary" type="submit">Add Comment</button>
					</div>	
				</form>
			</div>

		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>