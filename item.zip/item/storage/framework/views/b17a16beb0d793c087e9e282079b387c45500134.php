<?php $__env->startSection('header'); ?>

<h1 class="title">New Invoice</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="b1">
  <div class="field columns">
    <a class="button is-warning" href="<?php echo e(url('/')); ?>">Back</a>
  </div>
	<?php if(count($errors)): ?>
    <div class="notification is-danger">
      <button class="delete"></button>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </ul>
    </div>
     <?php endif; ?>
	<form id="listing" method="post" action="<?php echo e(url('invoice/create')); ?>">
    <div class="field columns">
        <div class="field-label is-normal column is-narrow">
         <label class="label is-2">Invoice Name :</label>
        </div>
        <div class="field-body">
         <div class="field is-grouped ">
            <p class="control">
              <input name="invoice_name" class="input is-3" type="text" placeholder="Name">
          </p>
        </div>
    </div>
    </div>
    
    <?php echo e(csrf_field()); ?>

		<div class="columns is-desktop">
		<div class="column" align="center">Item Name</div>
		<div class="column" align="center"># of items</div>
		<div class="column" align="center">Price</div>
		<div class="column" align="center">Total</div>
		<div class="column" align="center"></div>

		</div>
		<ul v-show="listStatus">
		  <li v-for="(key, item) in list" style="margin-bottom: 5px;">
	      
		      <div class="columns is-desktop">
		        <div class="column"><input type="text" class="input" name="item[]" v-model="item.item"></div>
		        <div class="column"><input type="number" class="input" name="qty[]" v-model="item.qty" placeholder="Quantity"></div>
		        <div class="column"><input type="number" class="input" name="price[]" v-model="item.price" placeholder="Price"></div>
		        <div class="column"><input type="text" class="input" name="total[]" v-model="item.total" placeholder="Total" value="{{ item.qty * item.price | currency}}" disabled></div>
		        <div class="column">
		        <a class="delete is-medium" href="#" v-on:click="removeElement(index)"></a>
		        </div>

		      </div>
	       
	      </li>
	    </ul>
	    <button type="button" class="button is-dark is-focused" v-on:click="optionClick">+ Add Item</button>
      <div class="field has-addons has-addons-right">
        <p class="control">
          <label class="label">SubTotal: {{ subtotal |currency }}</label>
          <label class="label">Tax:&nbsp;&nbsp;&nbsp;<input type="text" name="tax" v-model="tax" ></label>
          <label class="label">Total:&nbsp;{{ subtotal + ((subtotal/100) * tax) |currency}}<input type="hidden" name="total" v-model="total" value="{{ subtotal + ((subtotal/100) * tax)}}"></label>
        </p>
      </div>
      <div class="block">
      <button class="button is-warning" >Create</button>
      </div>
	</form>
	
	
	
</div>
<script type="text/javascript" src="<?php echo e(url('js/vue.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/jquery.js')); ?>"></script>
  <script>
    new Vue({
        el: '#app',
        data: {      
             list: [],
             listResult: '',
             tax : 0,
        },
        computed: {
          listStatus: function () {
            return (this.list.length > 0) ? true : false; 
          },
          total: function (){
            return this.list.item.qty  *  this.list.item.price;
          },
          subtotal:function()
          {
          	return this.list.reduce(function(total,item){
              	return  total + (item.qty * item.price);
            },0);
          }
      },
        methods: {
          optionClick: function() {
            this.list.push({
              item: '',
              qty: '',
              price: '',
              total: '',
            });
          },
          total:function(){
            var total=0;
            this.list.forEach(function(){
              total=this.item.qty*this.item.price;
            });
            return total;
          },

          removeElement: function (index) {
            this.list.splice(index, 1);
          },
          
        }
    })
    
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('invoice.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>