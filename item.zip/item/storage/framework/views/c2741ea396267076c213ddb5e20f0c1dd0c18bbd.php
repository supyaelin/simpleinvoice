<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1><?php echo e($task->body); ?></h1>
</body>
</html>