<?php $__env->startSection('content'); ?>

<div class="container">

  <div class="row">

    <div class="col-sm-8 blog-main">
    	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      		<?php echo $__env->make("posts.post", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    	<nav class="blog-pagination">
		<a class="btn btn-primary" href="#">Older</a>
		<a class="btn btn-secondary disabled" href="#">Newer</a>
		</nav>
     </div>
     <?php echo $__env->make("layouts.sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div><!-- /.row -->

</div><!-- /.container -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>