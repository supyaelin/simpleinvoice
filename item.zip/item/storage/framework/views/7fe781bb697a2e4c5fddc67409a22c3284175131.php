<?php 
	$str = new DateTime($post->created_at);
	
 ?>
<div class="blog-post">
	<h2 class="blog-post-title"><a href="<?php echo e(url('/')); ?>/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h2>
	<p class="blog-post-meta"><?php echo e($str->format('M d, Y')); ?></p>

	<p><?php echo e($post->body); ?></p>
</div><!-- /.blog-post -->






