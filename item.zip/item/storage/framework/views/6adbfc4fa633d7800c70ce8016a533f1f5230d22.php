<?php $__env->startSection('header'); ?>

<h1 class="title">Simple Invoice</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="b1">
	<?php if(count($errors)): ?>
    <div class="notification is-success">
      <button class="delete"></button>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </ul>
    </div>
     <?php endif; ?>
     <div class="field columns">
        <div class="field-body">
         <div class="field is-grouped ">
         
          <p class="control">
              <input name="invoice_name" v-model="searchString" class="input is-3" type="text" placeholder="" value="<?php echo e($id); ?>">
          </p>
          <p class="control">
          	  <a class="button is-dark" href="<?php echo e(url('invoice/search')); ?>/{{ searchString }}">Search</a>
          </p>
        </div>
        <div class="field has-addons has-addons-right">
	    	<a class="button is-warning" href="<?php echo e(url('invoice/create')); ?>">+ Add Invoice</a>
	    </div>
    </div>
    </div>
	<br>    
	<table class="table">
	  <thead>
	    <tr>
	      <th><abbr title="Invoice name">Invoice name</abbr></th>
	      <th><abbr title="quantity"># of items</abbr></th>
	      <th><abbr title="total">Total</abbr></th>
	      <th><abbr title="pdf"></abbr></th>
	    </tr>
	  </thead>
	  <tbody>
	  	<?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	  	<tr>
	  		<td><a href="<?php echo e(url('invoice')); ?>/<?php echo e($invoice->id); ?>" title=""><?php echo e($invoice->invoice_name); ?></a></td>
      		<th><?php echo e($invoice->count); ?></th>
      		<td><?php echo e($invoice->total); ?></td>
      		<td><a href="<?php echo e(url('invoice/download/')); ?>/<?php echo e($invoice->id); ?>" title="pdf">PDF</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      			<a href="<?php echo e(url('invoice/remove/')); ?>/<?php echo e($invoice->id); ?>" title="remove">Remove</a>
      		</td>
	  	</tr>

	  	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  	
   </table>
   <div>
   	<?php echo e($invoices->links()); ?>

   </div>
    
</div>

<script type="text/javascript" src="<?php echo e(url('js/vue.js')); ?>"></script>
<script>
    var demo = new Vue({
    el: '#app',
    data: {
        searchString:'',
        
    },
    computed: {
        
    },
    methods: {
      
    }
  });
  </script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('invoice.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>