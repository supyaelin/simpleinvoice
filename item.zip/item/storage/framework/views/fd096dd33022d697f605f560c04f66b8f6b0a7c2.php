<!DOCTYPE html>
<html lang="en">
    <head>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                </div>
                <ul>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li>
                        <a href="<?php echo e(url('/')); ?>/tasks/<?php echo e($task->id); ?>"><?php echo e($task->body); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
                

            </div>
        </div>
    </body>
</html>
