<?php $__env->startSection('content'); ?>

<?php 
	{{ Form::open(['method' => 'POST','style'=>'display:inline']) }}
	{{ Form::open(array('url'=>'login'))}}
    {{ $errors->first('email') }}
    {{ $errors->first('password') }}
    {{ Form::label('email', 'Email Address') }}
    {{ Form::text('email', Input::old('email'), array('placeholder' => 'awesome@awesome.com')) }}
    {{ Form::label('password', 'Password') }}
    {{ Form::password('password') }}
	{{ Form::submit('Submit!') }}
	{{ Form::close() }}
 ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>