<?php

Route::get('/', 'ItemController@index');
Route::get('/invoice/create', 'ItemController@add');
Route::post('/invoice/create', 'ItemController@store');

Route::get('/invoice/{invoice}', 'ItemController@edit');
Route::get('/api/delete/{id}', 'ItemController@delete');

Route::get('/invoice/download/{invoices}','ItemController@download');

Route::get('/invoice/search/{id}', 'ItemController@search');

Route::put('/invoice/{invoice}', 'ItemController@update');
Route::delete('/invoice/{id}','ItemController@remove');
Route::post('/invoice/search','ItemController@searching');



