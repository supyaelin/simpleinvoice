<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Item;
use App\Invoice;
use Illuminate\Support\Facades\Validator;

class ItemController extends Controller
{
    public function index()
    {
    	$invoices = Invoice::latest()->paginate(3);
        for ($i=0; $i < count($invoices); $i++) { 
            $invoices[$i]['count'] = Count(Item::where('invoice_id','=',$invoices[$i]['id'])->get());
        }
        $id = "";
        return view('invoice.index',compact('invoices','id'));
    }
    public function add()
    {
        return view('invoice.new');
    }
    
    public function store(Request $request)
      {
            $this->validate($request, [
                'invoice_name' => 'required|unique:invoices,invoice_name',
                'tax' => 'required',
                'total' => 'required',
                'item' => 'required',
                'qty' => 'required',
                'price' => 'required',
                'total' => 'required',
            ]);
            // $arr = Invoice::where('invoice_name','LIKE',$request->get('invoice_name'))->get();
            // if(count($arr) == 0)
            // {
                $invoice = Invoice::create([
                    'invoice_name' => $request->get('invoice_name'),
                    'tax' => (int)$request->get('tax'),
                    'total' => (int)$request->get('total')
                ]);
                $invoice_id  = $invoice->id;
                for ($i=0; $i < count($request->get('item')) ; $i++) { 
                    Item::create([
                        'invoice_id' => $invoice_id,
                        'name' => $request->get('item')[$i],
                        'qty'  => $request->get('qty')[$i],
                        'price'  => $request->get('price')[$i],
                        'total'  => $request->get('qty')[$i] * $request->get('price')[$i]
                    ]);
                }
                return redirect('/')
                    ->withErrors(["Invoice Added Successfully!"]);
            // }
            // return back()
                // ->withErrors(["Invoice Name already Exit!","Please choose Another Invoice Name!"]);
            
       }
    public function edit(Invoice $invoice)
    {
        $item = Item::where('invoice_id','=',$invoice->id)->get();
        return view("invoice/edit",compact('item','invoice'));
    }
    public function delete($id)
    {
        $item = Item::find($id);    
        $item->delete();

        return "delete";
    }
    public function remove(Invoice $invoice)
    {
        $item = Item::where('invoice_id','=',$invoice->id)->delete();
        $inv = Invoice::find($invoice->id);    
        $inv->delete();

        return back();
    }
    public function update(Request $request)
    {
        // $this->validate($request, [
        //     'tax' => 'required',
        //     'total' => 'required',
        //     'item' => 'required',
        //     'qty' => 'required|numeric',
        //     'price' => 'required|numeric',
        // ]);
        $invoice_id = $request->get('invoice_id');
        echo $invoice_id;exit;
        $invoice = Invoice::where('id', '=', $invoice_id)
                    ->update(
                        [
                            'tax' => $request->get('tax'),
                            'total' => $request->get('total')
                        ]
                    );
            
        for ($i=0; $i < count($request->get('item')) ; $i++) { 
            Item::updateOrCreate(
              [
                'id' => $request->get('id')[$i],
                'invoice_id' => $invoice_id
              ],
              [
                'invoice_id' => $invoice_id,
                'name' => $request->get('item')[$i],
                'qty'  => $request->get('qty')[$i],
                'price'  => $request->get('price')[$i],
                'total'  => $request->get('qty')[$i] * $request->get('price')[$i]
              ]);
            
        }

        return "success";
    }
    public function download(Invoice $invoices)
    {
        $items = Item::where('invoice_id','=',$invoices->id)->get();
        return view('invoice.download',compact('items','invoices'));
    }
    public function search($id)
    {
        $invoices = Invoice::where('invoice_name','LIKE','%'.$id .'%')->paginate(3);
        for ($i=0; $i < count($invoices); $i++) { 
            $invoices[$i]['count'] = Count(Item::where('invoice_id','=',$invoices[$i]['id'])->get());
        }

        return view('invoice.index',compact('invoices','id'));
    } 
    
}