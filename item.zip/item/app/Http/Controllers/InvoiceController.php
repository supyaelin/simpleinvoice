<?php

namespace App\Http\Controllers;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Request;

class InvoiceController extends Controller
{
    public function index()
    {
       return view('invoice.new');
    }
    public function create()
    {
        echo "Hello";exit;
        return view('invoice.new');
        //$posts = Post::orderBy('created_at','desc')->get();
        // $posts = Post::latest()->get();
        // return view('posts.index',compact('posts'));
    }
    
}