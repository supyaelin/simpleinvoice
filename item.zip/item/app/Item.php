<?php 
namespace App;

class Item extends Model
{
	protected $fillable = [
         'invoice_id','name','qty','price','total'
    ];
 //    public function comments()
	// {
	// 	return $this->hasMany(Comment::class);
	// }
	// public function addComment($body)
	// {
	// 	$this->comments()->create(compact('body'));
	// }
}
