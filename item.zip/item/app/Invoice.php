<?php 
namespace App;

class Invoice extends Model
{
	protected $fillable = [
        'invoice_name','tax','total'
    ];
}
