<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="{{ url('css/bulma.css') }}" rel="stylesheet">
   <style type="text/css">
    .b1{
      padding: 15px;
      margin:0 auto;
      width:800px;
    }
</style> 
  </head>

  <body id="app">
  <section class="hero is-dark">
    <div class="hero-body">
      <div class="container">
        @yield('header')
      </div>
    </div>
  </section>
  <br>
  <div class="container">
      @yield('content')  
  </div>
    
  
  </body>
</html>
