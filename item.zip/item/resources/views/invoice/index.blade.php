@extends('invoice.master')

@section('header')

<h1 class="title">Simple Invoice</h1>

@endsection

@section('content')
<div class="b1">
	@if(count($errors))
    <div class="notification is-success">
      <button class="delete"></button>
      <ul>
        @foreach($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
     @endif
     <div class="field columns">
        <div class="field-body">
         <div class="field is-grouped ">
         
          <p class="control">
              <input name="invoice_name" v-model="searchString" class="input is-3" type="text" placeholder="" value="{{ $id }}">
          </p>
          <p class="control">
          	  <a class="button is-dark" href="{{url('invoice/search')}}/@{{ searchString }}">Search</a>
          </p>
        </div>
        <div class="field has-addons has-addons-right">
	    	<a class="button is-warning" href="{{ url('invoice/create') }}">+ Add Invoice</a>
	    </div>
    </div>
    </div>
	<br>    
	<table class="table">
	  <thead>
	    <tr>
	      <th><abbr title="Invoice name">Invoice name</abbr></th>
	      <th><abbr title="quantity"># of items</abbr></th>
	      <th><abbr title="total">Total</abbr></th>
	      <th><abbr title="pdf"></abbr></th>
	    </tr>
	  </thead>
	  <tbody>
	  	@foreach($invoices as $invoice)
	  	<tr>
	  		<td><a href="{{ url('invoice')}}/{{ $invoice->id }}" title="">{{ $invoice->invoice_name }}</a></td>
      		<th>{{ $invoice->count }}</th>
      		<td>{{ $invoice->total }}</td>
      		<td><a href="{{url('invoice/download/')}}/{{ $invoice->id }}" title="pdf">PDF</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      			<a href="{{url('invoice/remove/')}}/{{ $invoice->id }}" title="remove">Remove</a>
      		</td>
	  	</tr>

	  	@endforeach
	  	
   </table>
   <div>
   	{{ $invoices->links()}}
   </div>
    
</div>

<script type="text/javascript" src="{{ url('js/vue.js') }}"></script>
<script>
    var demo = new Vue({
    el: '#app',
    data: {
        searchString:'',
        
    },
    computed: {
        
    },
    methods: {
      
    }
  });
  </script>  
@endsection