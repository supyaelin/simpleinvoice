<?php

		use App\Menu;

		ob_start();
		require('fpdf.php');

		$fpdf = new Fpdf();		
	    $fpdf->AddPage("P","A4");
	    $fpdf->SetFont('Times','B',20);
	     
	    $fpdf->SetFillColor(255,0,0);
	    $fpdf->SetTextColor(255);
	    $fpdf->SetDrawColor(25,0,0);
	    $fpdf->SetLineWidth(.3);
	    $fpdf->SetFont('','B');
	    
	    $w = array(70, 35, 40, 45);
	    $fpdf->SetFillColor(224,235,255);
	    $fpdf->SetTextColor(0);
	    $fpdf->SetFont('');	   
	    
	    $fpdf->Cell(0,6,"Invoice",0,0,'C');
	    $fpdf->Ln();
	  	$fpdf->Ln();
	  	$fpdf->Ln();

	  	$fpdf->SetFont('Times','B',10);
	  	$fpdf->Cell(145,6,"Invoice Name :",0,0,'R');
	  	$fpdf->SetFont('Times','',10);
    	$fpdf->Cell(45,6,$invoices->invoice_name,0,0,'L');
    	$fpdf->Ln();

	  	$fpdf->SetFont('Times','B',10);
	  	$fpdf->Cell($w[0],6,"Item Name",1,0,'C');
	    $fpdf->Cell($w[1],6,'Price',1,0,'C');
        $fpdf->Cell($w[2],6,'Quantity',1,0,'C');
        $fpdf->Cell($w[3],6,'Total',1,0,'C');       
        $fpdf->Ln();

        $fpdf->SetFont('Times','',10);
        $subtotal = 0;
        foreach($items as $item)
		{			
			$fpdf->Cell($w[0],6,$item->name,1,0,'L');			
	        $fpdf->Cell($w[1],6,$item->price,1,0,'R');
	        $fpdf->Cell($w[2],6,$item->qty,1,0,'R');
	        $fpdf->Cell($w[3],6,$item->total,1,0,'R');	        
	        $fpdf->Ln();  
	        $subtotal += (int)$item->total;
	    }

    	$fpdf->Cell(145,6,"Subtotal :",0,0,'R');
    	$fpdf->Cell(45,6,"$".$subtotal,1,0,'R');
    	$fpdf->Ln();
    	$fpdf->Cell(145,6,"Tax :",0,0,'R');
    	$fpdf->Cell(45,6,$invoices->tax."%",1,0,'R');
    	$fpdf->Ln();
    	$fpdf->Cell(145,6,"Total :",0,0,'R');
    	$fpdf->Cell(45,6,"$".$invoices->total,1,0,'R');

    	$fpdf->SetY(0);      
        $fpdf->SetFont('Times','I',8);   

        $fpdf->SetY(266);      
        $fpdf->SetFont('Times','I',8);        
        $fpdf->Cell(0,10,'Page '.$fpdf->PageNo(),0,0,'R');

        $fpdf->Output();
        exit;
		ob_end_flush(); 