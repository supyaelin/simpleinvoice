<!DOCTYPE html>
<html>
<head>
    <title>Vue.js + Laravel Pagination</title>
    <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">

</head>
<body>
<div class="container">
    <h1>Stories</h1>
    <table class="table table-striped">
        <tr>
            <th>#</th>
            <th>Plot</th>
            <th>Writer</th>
        </tr>
        <tr v-for="story in stories" is="story" :story="story"></tr>
    </table>
    <template id="template-story">
        <tr>
            <td>
                @{{story.id}}
            </td>
            <td class="col-md-6">
                @{{story.plot}}
            </td>
            <td>
                @{{story.writer}}
            </td>
        </tr>
    </template>
</div>
<script src="http://cdnjs.cloudflare.com/ajax/libs/vue/1.0.24/vue.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/vue-resource/0.7.0/vue-resource.js"></script>
<script type="text/javascript">
    Vue.component('story', {
        template: '#template-story',
        props: ['story'],
    })
    new Vue({
        el: '.container',
        data: {
            stories: [],
            pagination: {}
        },
        ready: function () {
            this.fetchStories()
        },
        methods: {
            fetchStories: function (page_url) {
                let vm = this;
                page_url = page_url || '/api/stories'
                this.$http.get(page_url)
                    .then(function (response) {
                        vm.makePagination(response.data)
                        vm.$set('stories', response.data.data)
                    });
            },
            makePagination: function(data){
                let pagination = {
                    current_page: data.current_page,
                    last_page: data.last_page,
                    next_page_url: data.next_page_url,
                    prev_page_url: data.prev_page_url
                }
                this.$set('pagination', pagination)
            }
        }
    });
</script>
</body>
</html>